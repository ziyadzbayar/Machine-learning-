# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 23:06:10 2025

@author: ziyad
"""
import pandas as pd 
from sklearn.model_selection import train_test_split
import statsmodels.api as sm

file_path='C:\\Data Analyste\\RLM_VENTES.xls'
data=pd.read_excel(file_path)
print(data.head())



corr_matrix=data.drop(columns=["Semestre"]).corr()
print("\nMartice de correlation:")
print(corr_matrix)


"""Separation des X et y"""
X=data.drop(columns=["Ventes","Semestre"],axis=1)
y=data["Ventes"]

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
print('\nTaille de l\'ensemble d\'entrainement : ',X_train.shape)
print('\nTaille de l\'ensemble de test : ',X_test.shape)


#Construire le modele
X_train_with_const=sm.add_constant(X_train)
model=sm.OLS(y_train,X_train_with_const).fit()
print(model.summary())



 