# -*- coding: utf-8 -*-
"""
Created on Fri Nov 28 20:21:38 2025

@author: ziyad
"""


import pandas as pd 
from sklearn.model_selection import train_test_split
import statsmodels.api as sm

file_path='C:\\Data Analyste\\RLM_VENTES.xls'
data=pd.read_excel(file_path)
print(data.head())



corr_matrix=data.drop(columns=["Semestre"]).corr()
print("\nMartice de correlation:")
print(corr_matrix)


"""Separation des X et y"""
X=data.drop(columns=["Ventes","Semestre"],axis=1)
y=data["Ventes"]

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
print('\nTaille de l\'ensemble d\'entrainement : ',X_train.shape)
print('\nTaille de l\'ensemble de test : ',X_test.shape)





#fonction ascendentes
def forward_selection(X,y,significance_level=0.05):
    selected_features=[]
    restantes=list(X.columns)
    while restantes:
        p_values={}
        for feature in restantes:
            model=sm.OLS(y,sm.add_constant(X[selected_features + [feature]])).fit()
            p_values[feature]=model.pvalues[feature]
        
        best_feature=min(p_values,key=p_values.get)
        if p_values[best_feature]< significance_level:
            selected_features.append(best_feature)
            restantes.remove(best_feature)
        else:
            break
    return  selected_features

vars_selectionnees=forward_selection(X_train,y_train)
print("les variables explicatives retenues :",vars_selectionnees)

X_train_fs=sm.add_constant(X_train[vars_selectionnees])
model=sm.OLS(y_train,X_train_fs).fit()
print(model.summary())
