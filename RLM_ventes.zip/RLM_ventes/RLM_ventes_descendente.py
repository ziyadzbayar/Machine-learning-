# -*- coding: utf-8 -*-
"""
Created on Fri Nov 28 20:31:54 2025

@author: ziyad
"""



import pandas as pd 
from sklearn.model_selection import train_test_split
import statsmodels.api as sm

file_path='C:\\Data Analyste\\RLM_VENTES.xls'
data=pd.read_excel(file_path)
print(data.head())



corr_matrix=data.drop(columns=["Semestre"]).corr()
print("\nMartice de correlation:")
print(corr_matrix)


"""Separation des X et y"""
X=data.drop(columns=["Ventes","Semestre"],axis=1)
y=data["Ventes"]

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
print('\nTaille de l\'ensemble d\'entrainement : ',X_train.shape)
print('\nTaille de l\'ensemble de test : ',X_test.shape)


""" fonction descendentes"""
def backward_elemination(X,y,significant_level=0.05):
    selected_features=[]
    while True:
        p_values=[]
        for feature in selected_features:
            model=sm.OLS(X,sm.add_constant(X[selected_features])).fit()
            p_value=model.pvalues[feature]
            p_values.append((feature,p_value))
            worst_feature,worst_p_value=max(p_values,key=lambda x: x[1])
            if worst_p_value > significant_level:
                selected_features.remove(worst_feature)
            else:
                break
        return selected_features


vars_selectionnees=backward_elemination(X_train,y_train)
print("les variables explicatives retenues :",vars_selectionnees)

X_train_fs=sm.add_constant(X_train[vars_selectionnees])
model=sm.OLS(y_train,X_train_fs).fit()
print(model.summary())
